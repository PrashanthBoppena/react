// Dashboard.jsx
import React from 'react';
import { Container, Grid, Paper, Typography, Button, Avatar, Box, List, ListItem, ListItemText } from '@mui/material';
import PieChartComponent from './CustomPieChart';  // Adjust the path as necessary

const Customer360Dashboard = () => {
  // Data for different pie charts
  const data1 = {
    labels: ['Loremipsum', 'Loremipsum', 'Loremipsum'],
    datasets: [
      {
        data: [40, 30, 30],
        backgroundColor: ['#0088FE', '#00C49F', '#FFBB28'],
        hoverBackgroundColor: ['#0077E6', '#00B07E', '#E6A825'],
      },
    ],
  };

  const data2 = {
    labels: ['Loremipsum', 'Loremipsum'],
    datasets: [
      {
        data: [75, 25],
        backgroundColor: ['#4caf50', '#ffeb3b'],
        hoverBackgroundColor: ['#388e3c', '#fbc02d'],
      },
    ],
  };

  const data3 = {
    labels: ['Loremipsum', 'Loremipsum', 'Loremipsum'],
    datasets: [
      {
        data: [50, 25, 25],
        backgroundColor: ['#3f51b5', '#e91e63', '#9c27b0'],
        hoverBackgroundColor: ['#303f9f', '#c2185b', '#7b1fa2'],
      },
    ],
  };

  const data4 = {
    labels: ['Loremipsum', 'Loremipsum', 'Loremipsum'],
    datasets: [
      {
        data: [80, 10, 10],
        backgroundColor: ['#009688', '#ffc107', '#f44336'],
        hoverBackgroundColor: ['#00796b', '#ffa000', '#d32f2f'],
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
  };

  return (
    <Container>
      {/* Header */}
      <Paper style={{ padding: '20px', textAlign: 'center', marginBottom: '20px', backgroundColor: '#f5f5f5' }}>
        <Typography variant="h4" style={{ fontWeight: 'bold' }}>Contactless SIM Delivery</Typography>
        <Typography variant="subtitle1">We will deliver your SIM safely</Typography>
      </Paper>

      <Grid container spacing={3}>
        {/* Profile and Accounts Section */}
        <Grid item xs={12} md={8}>
          <Paper style={{ padding: '20px', backgroundColor: '#f0f0f0' }}>
            <Grid container spacing={2} alignItems="center">
              {/* Profile Section */}
              <Grid item xs={12} md={6}>
                <Grid container spacing={2} alignItems="center">
                  <Grid item>
                    <Avatar src="https://via.placeholder.com/150" alt="Robert Lewandowski" style={{ width: 60, height: 60 }} />
                  </Grid>
                  <Grid item>
                    <Typography variant="h6">Robert Lewandowski</Typography>
                    <Typography variant="body2">Individual Customer</Typography>
                    <Typography variant="body2">8800661224</Typography>
                  </Grid>
                </Grid>
                <Box mt={2}>
                  <Grid container spacing={1}>
                    <Grid item xs={6}>
                      <Button variant="contained" fullWidth style={{ marginBottom: '10px', backgroundColor: '#64b5f6', color: 'white' }}>
                        Load Wallet
                      </Button>
                    </Grid>
                    <Grid item xs={6}>
                      <Button variant="contained" fullWidth style={{ marginBottom: '10px', backgroundColor: '#64b5f6', color: 'white' }}>
                        Re-Charge
                      </Button>
                    </Grid>
                    <Grid item xs={6}>
                      <Button variant="contained" fullWidth style={{ marginBottom: '10px', backgroundColor: '#64b5f6', color: 'white' }}>
                        Pay Bills
                      </Button>
                    </Grid>
                    <Grid item xs={6}>
                      <Button variant="contained" fullWidth style={{ backgroundColor: '#64b5f6', color: 'white' }}>
                        My Overview
                      </Button>
                    </Grid>
                  </Grid>
                </Box>
              </Grid>

              {/* Accounts Section */}
              <Grid item xs={12} md={6}>
                <Paper style={{ padding: '20px' }}>
                  <Typography variant="h6">My Accounts</Typography>
                  <List>
                    <ListItem>
                      <ListItemText primary="Postpaid" secondary="2133069 (Active)" />
                    </ListItem>
                    <ListItem>
                      <ListItemText primary="Postpaid" secondary="2133058 (Suspended)" />
                    </ListItem>
                    <ListItem>
                      <ListItemText primary="Broadband" secondary="8537365 (Active)" />
                    </ListItem>
                    <ListItem>
                      <ListItemText primary="DTH" secondary="56789326 (De-Activated)" />
                    </ListItem>
                  </List>
                </Paper>
              </Grid>
            </Grid>
          </Paper>
        </Grid>

        {/* Wallet Section */}
        <Grid item xs={12} md={4}>
          <Paper style={{ padding: '20px', textAlign: 'center' }}>
            <Typography variant="h6">Wallet</Typography>
            <Typography variant="h4" style={{ margin: '20px 0' }}>₹146.50</Typography>
            <Button variant="contained" fullWidth>Add Money</Button>
          </Paper>
        </Grid>

        {/* Summary Section */}
        <Grid item xs={12}>
          <Grid container spacing={3}>
            <Grid item xs={12} md={3}>
              <Paper style={{ padding: '20px', textAlign: 'center' }}>
                <Typography variant="h6">Total Request Summary</Typography>
                <Box display="flex" justifyContent="center" alignItems="center" height="200px">
                  <PieChartComponent data={data1} options={options} />
                </Box>
              </Paper>
            </Grid>
            <Grid item xs={12} md={3}>
              <Paper style={{ padding: '20px', textAlign: 'center' }}>
                <Typography variant="h6">On-Time Renewals</Typography>
                <Box display="flex" justifyContent="center" alignItems="center" height="200px">
                  <PieChartComponent data={data2} options={options} />
                </Box>
              </Paper>
            </Grid>
            <Grid item xs={12} md={3}>
              <Paper style={{ padding: '20px', textAlign: 'center' }}>
                <Typography variant="h6">Total Dispute Summary</Typography>
                <Box display="flex" justifyContent="center" alignItems="center" height="200px">
                  <PieChartComponent data={data3} options={options} />
                </Box>
              </Paper>
            </Grid>
            <Grid item xs={12} md={3}>
              <Paper style={{ padding: '20px', textAlign: 'center' }}>
                <Typography variant="h6">On-Time Bill Payments</Typography>
                <Box display="flex" justifyContent="center" alignItems="center" height="200px">
                  <PieChartComponent data={data4} options={options} />
                </Box>
              </Paper>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      
    </Container>
  );
};

export default Customer360Dashboard;
