import React from 'react';
import { Typography, Grid, Avatar, List, ListItem, ListItemText } from '@mui/material';
import PersonIcon from '@mui/icons-material/Person';
import EmailIcon from '@mui/icons-material/Email';
import PhoneIcon from '@mui/icons-material/Phone';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import AccountBalanceWalletIcon from '@mui/icons-material/AccountBalanceWallet';

const CustomerDetails = ({ customer }) => {
  return (
    <Grid container spacing={2}>
      <Grid item xs={12} sm={3} align="center">
        <Avatar sx={{ width: 100, height: 100 }}>
          <PersonIcon fontSize="large" />
        </Avatar>
      </Grid>
      <Grid item xs={12} sm={9}>
        <List>
          <ListItem disablePadding>
            <ListItemText primary={<Typography variant="h6">{customer.name}</Typography>} />
          </ListItem>
          <ListItem disablePadding>
            <ListItemText primary={<EmailIcon />} secondary={customer.email} />
          </ListItem>
          <ListItem disablePadding>
            <ListItemText primary={<PhoneIcon />} secondary={customer.phoneNumber} />
          </ListItem>
          <ListItem disablePadding>
            <ListItemText primary={<LocationOnIcon />} secondary={customer.address} />
          </ListItem>
          <ListItem disablePadding>
            <ListItemText primary={<AccountBalanceWalletIcon />} secondary={`Account Balance: ${customer.accountBalance}`} />
          </ListItem>
        </List>
      </Grid>
    </Grid>
  );
};

export default CustomerDetails;
